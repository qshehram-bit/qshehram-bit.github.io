RAMMO & BUDDY — BIRTHDAY WEBSITE
Open index.html to preview.
Keep the images folder beside index.html.
This version uses the 3 photos currently available in the conversation.
For a public link, upload the folder to a static hosting service.
